﻿namespace FortniteLauncher
{
    partial class FortniteLauncher
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            linkLabel1 = new LinkLabel();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            radioButton1 = new RadioButton();
            Settings = new RadioButton();
            asd = new RadioButton();
            guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            guna2GradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges1;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.Font = new Font("Segoe UI", 9F);
            guna2GradientButton1.ForeColor = Color.White;
            guna2GradientButton1.Location = new Point(134, 157);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientButton1.Size = new Size(1003, 59);
            guna2GradientButton1.TabIndex = 0;
            guna2GradientButton1.Text = "▶️: Ready to Jump into fortnite chapter 2 season 2? Begin Now!";
            guna2GradientButton1.Click += guna2GradientButton1_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(134, 238);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(222, 15);
            linkLabel1.TabIndex = 1;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "No Account? No Problem! Register Here!";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.Controls.Add(radioButton1);
            guna2GradientPanel1.Controls.Add(Settings);
            guna2GradientPanel1.Controls.Add(asd);
            guna2GradientPanel1.CustomizableEdges = customizableEdges3;
            guna2GradientPanel1.Location = new Point(0, 0);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2GradientPanel1.Size = new Size(92, 599);
            guna2GradientPanel1.TabIndex = 2;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(3, 28);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(70, 19);
            radioButton1.TabIndex = 3;
            radioButton1.TabStop = true;
            radioButton1.Text = "📅: Shop";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // Settings
            // 
            Settings.AutoSize = true;
            Settings.Location = new Point(3, 571);
            Settings.Name = "Settings";
            Settings.Size = new Size(85, 19);
            Settings.TabIndex = 3;
            Settings.TabStop = true;
            Settings.Text = "✨: Settings";
            Settings.UseVisualStyleBackColor = true;
            Settings.CheckedChanged += Settings_CheckedChanged;
            // 
            // asd
            // 
            asd.AutoSize = true;
            asd.Location = new Point(3, 3);
            asd.Name = "asd";
            asd.Size = new Size(74, 19);
            asd.TabIndex = 0;
            asd.TabStop = true;
            asd.Text = "▶️: Home";
            asd.UseVisualStyleBackColor = true;
            // 
            // FortniteLauncher
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1216, 604);
            Controls.Add(guna2GradientPanel1);
            Controls.Add(linkLabel1);
            Controls.Add(guna2GradientButton1);
            Name = "FortniteLauncher";
            Text = "Fortnite Launcher";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private LinkLabel linkLabel1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private RadioButton asd;
        private RadioButton Settings;
        private RadioButton radioButton1;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
    }
}
