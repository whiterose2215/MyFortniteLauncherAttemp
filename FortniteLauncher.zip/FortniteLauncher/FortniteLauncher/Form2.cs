﻿using Guna.UI2.WinForms;
using System;
using System.IO;
using System.Windows.Forms;
using WpfApp6.Services;
using static System.Windows.Forms.DataFormats;

namespace FortniteLauncher
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }


        private void guna2Button1_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Select A Fortnite Build";
                folderDialog.ShowNewFolderButton = false;

                DialogResult result = folderDialog.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string selectedPath = folderDialog.SelectedPath;


                    if (File.Exists(Path.Combine(selectedPath, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe")))
                    {
                        guna2TextBox1.Text = selectedPath;
                    }
                    else
                    {
                        MessageBox.Show("Please make sure the folder contains 'FortniteGame' and 'Engine'.");
                    }
                }
            }
        }


        private void button1_Click_1(object sender, EventArgs e)
        {

            string email = guna2TextBox1.Text;
            string password = guna2TextBox2.Text;
            string path = guna2TextBox1.Text;

            // Check if email, password, and path are provided
            if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(path))
            {
                // Save the data to config using UpdateINI
                UpdateINI.WriteToConfig("Auth", "Email", email);
                UpdateINI.WriteToConfig("Auth", "Password", password);
                UpdateINI.WriteToConfig("Auth", "Path", path);

                MessageBox.Show("Saved, You may begin Playing!");
            }
            else
            {
                MessageBox.Show("Please fill in all fields.");
            }
        }


        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

            UpdateINI.WriteToConfig("Auth", "Path", guna2TextBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Hide the current form (Form2)
            this.Hide();

            // Create an instance of Form1
            Form form = new Form();

            // Show Form1
            form.Show();
        }
    }
}