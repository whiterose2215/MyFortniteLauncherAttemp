using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Windows.Forms;
using WpfApp6.Services.Launch;
using WpfApp6.Services;

namespace FortniteLauncher
{
    public partial class FortniteLauncher : Form
    {
        public FortniteLauncher()
        {
            InitializeComponent();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            try
            {
                string path = UpdateINI.ReadValue("Auth", "Path");

                if (path != "NONE") 
                {
                    string fortniteExePath = Path.Combine(path, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe");

                    if (File.Exists(fortniteExePath)) 
                    {
                        if (UpdateINI.ReadValue("Auth", "Email") == "NONE" || UpdateINI.ReadValue("Auth", "Password") == "NONE")
                        {
                            MessageBox.Show("Please Add Your Eon Info In Settings");
                            return;
                        }

                        try
                        {
                            // Download required DLL
                            WebClient webClient = new WebClient(); //Read me            keep going                                                                 almost there                                                                            here!
                            string downloadUrl = "https://cdn.discordapp.com/attachments/1347159507280855053/1347211340640550963/Aurora.Runtime.dll?ex=67caffd5&is=67c9ae55&hm=d90b8e01e4c6b935cc0a9c3c141cc9f0f2acee120893b7e1531b1571265d8aec&"; //I use eon launch code, I will fix it later on but this is legit just for skidders so idc, also skidders please don't use this without crediting vtable (me) ty <3
                            string destinationPath = Path.Combine(path, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll");
                            webClient.DownloadFile(downloadUrl, destinationPath);
                        }                                               //very important replace that link with ur curl, I use aurora runtimes usually bc that works the best! Find it here; https://github.com/Beat-YT/Aurora.Runtime
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error downloading EonCurl.dll: {ex.Message}");
                            return;
                        }

                        // Start Fortnite process
                        string epicArgs = "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -fromfl=be -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck";

                        PSBasics.Start(path, epicArgs, UpdateINI.ReadValue("Auth", "Email"), UpdateINI.ReadValue("Auth", "Password"));
                        FakeAC.Start(path, "FortniteClient-Win64-Shipping_BE.exe", epicArgs, "r");
                        FakeAC.Start(path, "FortniteLauncher.exe", epicArgs, "dsf");

                        PSBasics._FortniteProcess.WaitForExit();

                        
                        try
                        {
                            FakeAC._FNLauncherProcess.Close();
                            FakeAC._FNAntiCheatProcess.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"There was an error closing processes: {ex.Message}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("FortniteClient-Win64-Shipping.exe not found. Please check the selected folder.");
                    }
                }
                else
                {
                    MessageBox.Show("Fortnite path is not configured. Please add your path in settings.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "https://discord.gg/Swwe6rwyxB",
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Discord link: {ex.Message}");
            }
        }

        private void Settings_CheckedChanged(object sender, EventArgs e)
        {
            if (Settings.Checked)
            {
                Form2 form2 = new Form2(); 
                form2.Show();
                this.Hide(); 
            }
        }

        // Other event handlers (if required)
        private void guna2TextBox1_TextChanged(object sender, EventArgs e) { }

        private void pictureBox1_Click(object sender, EventArgs e) { }
    }
}
